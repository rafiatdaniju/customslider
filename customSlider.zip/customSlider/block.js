(function () {
var el = wp.element.createElement;
var registerBlockType = wp.blocks.registerBlockType;
var MediaUpload = wp.blockEditor.MediaUpload;
var InspectorControls = wp.blockEditor.InspectorControls;
var Button = wp.components.Button;
var PanelBody = wp.components.PanelBody;

registerBlockType('custom/image-slider', {
    title: 'Image Slider',
    icon: 'images-alt2',
    category: 'common',
    attributes: {
        images: {
            type: 'array',
            default: [],
        },
    },

    edit: function(props) {
        var attributes = props.attributes;
        var setAttributes = props.setAttributes;
        var images = attributes.images;

        function onSelectImages(newImages) {
            var imageData = newImages.map(function(image) {
                return {
                    id: image.id,
                    url: image.url,
                    alt: image.alt,
                    width: image.width,
                    height: image.height
                };
            });
            setAttributes({ images: imageData });
        }

        function openMediaLibrary() {
            var upload = wp.media({
                title: 'Select Images for Slider',
                multiple: true,
                library: { type: 'image' }
            });
            
            upload.on('select', function() {
                var selected = upload.state().get('selection').toJSON();
                onSelectImages(selected);
            });
            
            upload.open();
        }

        // Create Inspector Controls
        var inspectorControls = el(InspectorControls, {},
            el(PanelBody, { title: 'Slider Settings' },
                el(MediaUpload, {
                    onSelect: onSelectImages,
                    allowedTypes: ['image'],
                    multiple: true,
                    value: images.map(function(img) { return img.id; }),
                    render: function(obj) {
                        return el(Button, {
                            onClick: obj.open,
                            isPrimary: true
                        }, 'Select Images');
                    }
                })
            )
        );

        // Create Block Content
        var blockContent;
        if (images.length === 0) {
            blockContent = el('div', { className: 'editor-image-slider' },
                el(Button, {
                    onClick: openMediaLibrary,
                    isPrimary: true
                }, 'Select Images')
            );
        } else {
            var imageElements = images.map(function(img, index) {
                return el('div', { 
                    className: 'image-preview',
                    key: index 
                },
                    el('img', {
                        src: img.url,
                        alt: img.alt
                    })
                );
            });

            blockContent = el('div', { className: 'editor-image-slider' },
                el('div', { className: 'image-preview-grid' },
                    imageElements
                )
            );
        }

        // Return both inspector controls and block content
        return el(wp.element.Fragment, {},
            inspectorControls,
            blockContent
        );
    },

    save: function() {
        return null; // Using PHP render callback
    }
});
})();